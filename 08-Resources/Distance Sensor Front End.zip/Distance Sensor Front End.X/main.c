 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/adc/adc.h"
#include "mcc_generated_files/dac/dac1.h"
#include <stdint.h>


int main(void)
{
    SYSTEM_Initialize();

    uint16_t filtered = 0;
    uint8_t first = 1;

    static const uint8_t brightness[6] = {
        0,   // Level 0
        51,   // Level 1
        102,  // Level 2
        153,  // Level 3
        204,  // Level 4
        255   // Level 5 brightest (not full 255)
    };

    while (1)
    {
        adc_result_t raw = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA0);
        uint16_t adcValue = (uint16_t)raw;

        if (first)
        {
            filtered = adcValue;
            first = 0;
        }
        else
        {
            int16_t diff = (int16_t)adcValue - (int16_t)filtered;
            filtered += (diff >> 3);   // divide by 8
        }

        uint8_t rawDac = (uint8_t)(filtered >> 2);

        uint8_t step = rawDac / 43;   // ~43 per bucket
        if (step > 5) step = 5;

        uint8_t dacValue = brightness[step];

        DAC1_SetOutput(dacValue);

        __delay_ms(20);
    }
}
