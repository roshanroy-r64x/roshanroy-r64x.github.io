/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define CLAP_IN_TRIS                 TRISAbits.TRISA0
#define CLAP_IN_LAT                  LATAbits.LATA0
#define CLAP_IN_PORT                 PORTAbits.RA0
#define CLAP_IN_WPU                  WPUAbits.WPUA0
#define CLAP_IN_OD                   ODCONAbits.ODCA0
#define CLAP_IN_ANS                  ANSELAbits.ANSELA0
#define CLAP_IN_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define CLAP_IN_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define CLAP_IN_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define CLAP_IN_GetValue()           PORTAbits.RA0
#define CLAP_IN_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define CLAP_IN_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define CLAP_IN_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define CLAP_IN_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define CLAP_IN_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define CLAP_IN_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define CLAP_IN_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define CLAP_IN_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA1 aliases
#define LIGHT_IN_TRIS                 TRISAbits.TRISA1
#define LIGHT_IN_LAT                  LATAbits.LATA1
#define LIGHT_IN_PORT                 PORTAbits.RA1
#define LIGHT_IN_WPU                  WPUAbits.WPUA1
#define LIGHT_IN_OD                   ODCONAbits.ODCA1
#define LIGHT_IN_ANS                  ANSELAbits.ANSELA1
#define LIGHT_IN_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define LIGHT_IN_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define LIGHT_IN_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define LIGHT_IN_GetValue()           PORTAbits.RA1
#define LIGHT_IN_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define LIGHT_IN_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define LIGHT_IN_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define LIGHT_IN_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define LIGHT_IN_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define LIGHT_IN_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define LIGHT_IN_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define LIGHT_IN_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set RA2 aliases
#define HUB_LED_TRIS                 TRISAbits.TRISA2
#define HUB_LED_LAT                  LATAbits.LATA2
#define HUB_LED_PORT                 PORTAbits.RA2
#define HUB_LED_WPU                  WPUAbits.WPUA2
#define HUB_LED_OD                   ODCONAbits.ODCA2
#define HUB_LED_ANS                  ANSELAbits.ANSELA2
#define HUB_LED_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define HUB_LED_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define HUB_LED_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define HUB_LED_GetValue()           PORTAbits.RA2
#define HUB_LED_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define HUB_LED_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define HUB_LED_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define HUB_LED_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define HUB_LED_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define HUB_LED_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define HUB_LED_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define HUB_LED_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RA3 aliases
#define DIST_ADC_TRIS                 TRISAbits.TRISA3
#define DIST_ADC_LAT                  LATAbits.LATA3
#define DIST_ADC_PORT                 PORTAbits.RA3
#define DIST_ADC_WPU                  WPUAbits.WPUA3
#define DIST_ADC_OD                   ODCONAbits.ODCA3
#define DIST_ADC_ANS                  ANSELAbits.ANSELA3
#define DIST_ADC_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define DIST_ADC_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define DIST_ADC_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define DIST_ADC_GetValue()           PORTAbits.RA3
#define DIST_ADC_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define DIST_ADC_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define DIST_ADC_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define DIST_ADC_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define DIST_ADC_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define DIST_ADC_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define DIST_ADC_SetAnalogMode()      do { ANSELAbits.ANSELA3 = 1; } while(0)
#define DIST_ADC_SetDigitalMode()     do { ANSELAbits.ANSELA3 = 0; } while(0)

// get/set RB0 aliases
#define MOTOR_FWD_TRIS                 TRISBbits.TRISB0
#define MOTOR_FWD_LAT                  LATBbits.LATB0
#define MOTOR_FWD_PORT                 PORTBbits.RB0
#define MOTOR_FWD_WPU                  WPUBbits.WPUB0
#define MOTOR_FWD_OD                   ODCONBbits.ODCB0
#define MOTOR_FWD_ANS                  ANSELBbits.ANSELB0
#define MOTOR_FWD_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define MOTOR_FWD_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define MOTOR_FWD_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define MOTOR_FWD_GetValue()           PORTBbits.RB0
#define MOTOR_FWD_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define MOTOR_FWD_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define MOTOR_FWD_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define MOTOR_FWD_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define MOTOR_FWD_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define MOTOR_FWD_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define MOTOR_FWD_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define MOTOR_FWD_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set RB1 aliases
#define MOTOR_REV_TRIS                 TRISBbits.TRISB1
#define MOTOR_REV_LAT                  LATBbits.LATB1
#define MOTOR_REV_PORT                 PORTBbits.RB1
#define MOTOR_REV_WPU                  WPUBbits.WPUB1
#define MOTOR_REV_OD                   ODCONBbits.ODCB1
#define MOTOR_REV_ANS                  ANSELBbits.ANSELB1
#define MOTOR_REV_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define MOTOR_REV_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define MOTOR_REV_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define MOTOR_REV_GetValue()           PORTBbits.RB1
#define MOTOR_REV_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define MOTOR_REV_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define MOTOR_REV_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define MOTOR_REV_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define MOTOR_REV_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define MOTOR_REV_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define MOTOR_REV_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define MOTOR_REV_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RC6 aliases
#define IO_RC6_TRIS                 TRISCbits.TRISC6
#define IO_RC6_LAT                  LATCbits.LATC6
#define IO_RC6_PORT                 PORTCbits.RC6
#define IO_RC6_WPU                  WPUCbits.WPUC6
#define IO_RC6_OD                   ODCONCbits.ODCC6
#define IO_RC6_ANS                  ANSELCbits.ANSELC6
#define IO_RC6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define IO_RC6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define IO_RC6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define IO_RC6_GetValue()           PORTCbits.RC6
#define IO_RC6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define IO_RC6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define IO_RC6_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define IO_RC6_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define IO_RC6_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define IO_RC6_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define IO_RC6_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define IO_RC6_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)

// get/set RC7 aliases
#define IO_RC7_TRIS                 TRISCbits.TRISC7
#define IO_RC7_LAT                  LATCbits.LATC7
#define IO_RC7_PORT                 PORTCbits.RC7
#define IO_RC7_WPU                  WPUCbits.WPUC7
#define IO_RC7_OD                   ODCONCbits.ODCC7
#define IO_RC7_ANS                  ANSELCbits.ANSELC7
#define IO_RC7_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define IO_RC7_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define IO_RC7_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define IO_RC7_GetValue()           PORTCbits.RC7
#define IO_RC7_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define IO_RC7_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define IO_RC7_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define IO_RC7_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define IO_RC7_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define IO_RC7_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define IO_RC7_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define IO_RC7_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/