#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/adc/adc.h"
#include "mcc_generated_files/dac/dac1.h"
#include "mcc_generated_files/uart/uart1.h"

/* ============================================================
 *   MOTOR CONTROL
 * ============================================================ */

static void Motor_Off(void)
{
    MOTOR_FWD_SetLow();
    MOTOR_REV_SetLow();
}

static void Motor_Forward(void)
{
    MOTOR_FWD_SetHigh();
    MOTOR_REV_SetLow();
}

/* ============================================================
 *   AARON LED TOGGLE DETECTION
 * ============================================================ */

static bool prevAaron = false;

static bool AaronToggle(void)
{
    bool now = CLAP_IN_GetValue();    // RA0 input
    bool changed = (now != prevAaron);
    prevAaron = now;
    return changed;
}

/* ============================================================
 *   UART SEND STRING
 * ============================================================ */

static void UART1_SendString(const char *s)
{
    while (*s)
    {
        while (!UART1_IsTxReady());
        UART1_Write(*s);
        s++;
    }
}

/* ============================================================
 *   ROSHAN BRIGHTNESS TABLE (REVERSED)
 * ============================================================ */

static const uint8_t brightnessLevels[6] =
{
    255,  // closest
    180,
    130,
    90,
    50,
    0     // farthest
};

/* ============================================================
 *   DISTANCE ? BRIGHTNESS
 * ============================================================ */

static uint8_t Distance_To_Brightness(void)
{
    ADPCH = DIST_ADC;     // RA3 ADC input
    ADCON0bits.GO = 1;
    while (ADCON0bits.GO);

    uint16_t value  = ADRES;    // 0?1023
    uint8_t dacRaw  = value >> 2;  // 0?255

    uint8_t bucket  = dacRaw / 43;
    if (bucket > 5) bucket = 5;

    return brightnessLevels[bucket];
}

/* ============================================================
 *   UART DISTANCE LOGGING
 * ============================================================ */

static void Log_Distance(void)
{
    ADPCH = DIST_ADC;
    ADCON0bits.GO = 1;
    while (ADCON0bits.GO);

    uint16_t value = ADRES;

    char buffer[40];
    sprintf(buffer, "Distance ADC: %u\r\n", value);
    UART1_SendString(buffer);
}

/* ============================================================
 *   STATE MACHINE
 * ============================================================ */

typedef enum
{
    HUB_IDLE = 0,
    HUB_MOTOR_OFF,
    HUB_MOTOR_ON
} hub_state_t;

static hub_state_t hubState = HUB_IDLE;

/* ============================================================
 *   MOTOR LOGIC (AARON ? QUINN)
 * ============================================================ */

static void Hub_Task(void)
{
    bool aaronLED     = CLAP_IN_GetValue();      // RA0
    bool quinnCovered = !LIGHT_IN_GetValue();    // RA1 LOW = covered

    switch (hubState)
    {
        case HUB_IDLE:
            Motor_Off();
            hubState = HUB_MOTOR_OFF;
            break;

        case HUB_MOTOR_OFF:
            if (AaronToggle())        // Aaron toggles ON
            {
                if (quinnCovered)
                    Motor_Forward();
                else
                    Motor_Off();

                hubState = HUB_MOTOR_ON;
            }
            break;

        case HUB_MOTOR_ON:
            if (AaronToggle())        // Aaron toggles OFF
            {
                Motor_Off();
                hubState = HUB_MOTOR_OFF;
            }
            break;
    }
}

/* ============================================================
 *   SMOOTH LED FADE VARIABLE
 * ============================================================ */

static uint8_t smoothBrightness = 0;

/* ============================================================
 *   MAIN LOOP (AARON ? QUINN ? ROSHAN)
 * ============================================================ */

void main(void)
{
    SYSTEM_Initialize();

    Motor_Off();
    prevAaron = CLAP_IN_GetValue();
    hubState  = HUB_IDLE;

    DAC1_SetOutput(0);  // LED starts off

    while (1)
    {
        Hub_Task();

        bool quinnCovered = !LIGHT_IN_GetValue();   // RA1 LOW = covered

        // LED follows the *motor state* instead of raw Aaron input
        bool hubEnabled = (hubState == HUB_MOTOR_ON) && quinnCovered;

        if (hubEnabled)
        {
            uint8_t target = Distance_To_Brightness();

            // Smooth fade-in (very gentle fade, alpha ? 0.08)
            smoothBrightness = (smoothBrightness * 23 + target * 2) / 25;

            DAC1_SetOutput(smoothBrightness);
        }
        else
        {
            // Smooth fade-out
            smoothBrightness = (smoothBrightness * 23 + 0 * 2) / 25;
            DAC1_SetOutput(smoothBrightness);
        }

        Log_Distance();
        __delay_ms(50);
    }
}
